package org.techtown.helloandroid;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class CheckActivity extends AppCompatActivity {
    //임의로 변화량 설정
    int quizChange = 1;
    int smileChange = -1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check);
        // 이미지 선언
        ImageView like = (ImageView) findViewById(R.id.like);
        ImageView quizup = (ImageView) findViewById(R.id.quizup);
        ImageView smileup = (ImageView) findViewById(R.id.smileup);
        ImageView smileup2 = (ImageView) findViewById(R.id.smileup2);
        ImageView sad = (ImageView) findViewById(R.id.sad);
        ImageView quizdown = (ImageView) findViewById(R.id.quizdown);
        ImageView smiledown = (ImageView) findViewById(R.id.smiledown);
        ImageView smiledown2 = (ImageView) findViewById(R.id.smiledown2);
        // 퀴즈변화량과 웃음변화량에 따른 메시지 출력조정 조건문
        if(quizChange >= 0) {
            like.setVisibility(View.VISIBLE);
            quizup.setVisibility(View.VISIBLE);
            quizdown.setVisibility(View.INVISIBLE);
            smileup.setVisibility(View.INVISIBLE);
            smiledown2.setVisibility(View.INVISIBLE);
            if(smileChange >=0) {
                sad.setVisibility(View.INVISIBLE);
                smileup2.setVisibility(View.VISIBLE);
                smiledown.setVisibility(View.INVISIBLE);
            }
            else {
                sad.setVisibility(View.VISIBLE);
                smileup2.setVisibility(View.INVISIBLE);
                smiledown.setVisibility(View.VISIBLE);
            }
        }
        else {
            sad.setVisibility(View.VISIBLE);
            quizup.setVisibility(View.INVISIBLE);
            quizdown.setVisibility(View.VISIBLE);
            smileup2.setVisibility(View.INVISIBLE);
            smiledown.setVisibility(View.INVISIBLE);
            if (smileChange >= 0) {
                like.setVisibility(View.VISIBLE);
                smileup.setVisibility(View.VISIBLE);
                smiledown2.setVisibility(View.INVISIBLE);
            } else {
                like.setVisibility(View.INVISIBLE);
                smileup.setVisibility(View.INVISIBLE);
                smiledown2.setVisibility(View.VISIBLE);
            }
        }
    }
}
