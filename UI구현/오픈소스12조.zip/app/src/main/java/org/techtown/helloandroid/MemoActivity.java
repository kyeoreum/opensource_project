package org.techtown.helloandroid;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MemoActivity extends AppCompatActivity {
    EditText mMemoEdit = null;
    TextFileManager mTextFileManager = new TextFileManager(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memo);

        mMemoEdit = (EditText) findViewById(R.id.memo_edit);

        ImageButton save_btn = (ImageButton) findViewById(R.id.save_btn);
        ImageButton delete_btn = (ImageButton) findViewById(R.id.delete_btn);
        /*Button load_btn = (Button) findViewById(R.id.load_btn);

        load_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String memoData = mTextFileManager.load();
                mMemoEdit.setText(memoData);
                Toast.makeText(getApplicationContext(),"불러오기 완료",Toast.LENGTH_LONG).show();
            }
        });*/
        save_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String memoData = mMemoEdit.getText().toString();
                mTextFileManager.save(memoData);
                mMemoEdit.setText("");
                Toast.makeText(getApplicationContext(),"저장 완료", Toast.LENGTH_LONG).show();
            }
        });
        delete_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mTextFileManager.delete();
                mMemoEdit.setText("");
                Toast.makeText(getApplicationContext(), "삭제 완료", Toast.LENGTH_LONG).show();
            }
        });
    }
    /*
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.load_btn: {
                String memoData = mTextFileManager.load();
                mMemoEdit.setText(memoData);
                Toast.makeText(this,"불러오기 완료",Toast.LENGTH_LONG).show();
                break;
            }
            case R.id.save_btn: {
                String memoData = mMemoEdit.getText().toString();
                mTextFileManager.save(memoData);
                mMemoEdit.setText("");
                Toast.makeText(this,"저장 완료", Toast.LENGTH_LONG).show();
                break;
            }
            case R.id.delete_btn: {
                mTextFileManager.delete();
                mMemoEdit.setText("");
                Toast.makeText(this, "삭제 완료", Toast.LENGTH_LONG).show();
            }
        }
    }
         */
}
