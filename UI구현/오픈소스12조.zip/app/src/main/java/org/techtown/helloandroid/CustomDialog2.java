package org.techtown.helloandroid;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;


public class CustomDialog2 {

    int i=0;

    private Context context;

    public CustomDialog2(Context context) {
        this.context = context;
    }

    // 호출할 다이얼로그 함수를 정의한다.
    public void callFunction(int num) {
        // 커스텀 다이얼로그를 정의하기위해 Dialog클래스를 생성한다.
        final Dialog dlg = new Dialog(context);
        // 액티비티의 타이틀바를 숨긴다.
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // 커스텀 다이얼로그의 레이아웃을 설정한다.
        dlg.setContentView(R.layout.custom_dialog2);
        // 커스텀 다이얼로그를 노출한다.
        dlg.show();
        // 커스텀 다이얼로그의 버튼과 이미지를 정의한다.
        ImageButton next = (ImageButton) dlg.findViewById(R.id.next);
        final ImageView imageview1 = (ImageView) dlg.findViewById(R.id.correct);
        final ImageView smilemessage = (ImageView) dlg.findViewById(R.id.correct2);
        // 정답 안내 이미지만 활성화한다.
        imageview1.setVisibility(View.VISIBLE);
        smilemessage.setVisibility(View.INVISIBLE);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 첫번째로 버튼 클릭 시 웃음 유도 이미지를 활성화한다.
                if(i==0) {
                    smilemessage.setVisibility(View.VISIBLE);
                    imageview1.setVisibility(View.INVISIBLE);
                    // dlg.dismiss();
                    i++;
                }
                // 버튼 한번 더 클릭 시 다이얼로그를 종료한다.
                else {
                    dlg.dismiss();
                }
            }
        });
    }
}