package org.techtown.helloandroid;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;

public class CustomDialog {
    int i=0;

    private Context context;

    public CustomDialog(Context context) {
        this.context = context;
    }

    // 호출할 다이얼로그 함수를 정의한다.
    public void callFunction(int num) {
        // 커스텀 다이얼로그를 정의하기위해 Dialog클래스를 생성한다.
        final Dialog dlg = new Dialog(context);
        // 커스텀 다이얼로그의 레이아웃을 설정한다.
        dlg.setContentView(R.layout.custom_dialog);
        // 액티비티의 타이틀바를 숨긴다.
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // 커스텀 다이얼로그를 노출한다.
        dlg.show();
        // 커스텀 다이얼로그의 버튼과 이미지를 정의한다.
        ImageButton next = (ImageButton) dlg.findViewById(R.id.next);
        final ImageView imageview1 = (ImageView) dlg.findViewById(R.id.incorrect1);
        final ImageView imageview2 = (ImageView) dlg.findViewById(R.id.incorrect2);
        final ImageView imageview4 = (ImageView) dlg.findViewById(R.id.incorrect4);
        final ImageView smilemessage = (ImageView) dlg.findViewById(R.id.incorrect5);
        // 이미지들을 비활성화한다.
        imageview1.setVisibility(View.INVISIBLE);
        imageview2.setVisibility(View.INVISIBLE);
        imageview4.setVisibility(View.INVISIBLE);
        smilemessage.setVisibility(View.INVISIBLE);
        // 각 선택지 선택 시 오답이미지를 활성화한다.
        switch(num) {
            case 1:
                imageview1.setVisibility(View.VISIBLE);
                break;
            case 2:
                imageview2.setVisibility(View.VISIBLE);
                break;
            case 4:
                imageview4.setVisibility(View.VISIBLE);
                break;
        }

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 첫번째로 버튼 클릭 시 웃음 유도 이미지를 활성화한다.
                if(i==0) {
                    smilemessage.setVisibility(View.VISIBLE);
                    imageview1.setVisibility(View.INVISIBLE);
                    imageview2.setVisibility(View.INVISIBLE);
                    imageview4.setVisibility(View.INVISIBLE);
                    i++;
                }
                // 버튼 한번 더 클릭 시 다이얼로그를 종료한다.
                else {
                    dlg.dismiss();
                }
            }
        });
    }
}