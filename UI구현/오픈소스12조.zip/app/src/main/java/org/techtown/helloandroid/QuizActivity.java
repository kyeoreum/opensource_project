package org.techtown.helloandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class QuizActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        // 커스텀 다이얼로그를 호출할 버튼을 정의
        ImageButton button1 = (ImageButton) findViewById(R.id.button1);
        ImageButton button2 = (ImageButton) findViewById(R.id.button2);
        ImageButton button3 = (ImageButton) findViewById(R.id.button3);
        ImageButton button4 = (ImageButton) findViewById(R.id.button4);

        // 커스텀 다이얼로그 호출할 클릭 이벤트 리스너 정의
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 커스텀 다이얼로그를 생성
                CustomDialog customDialog = new CustomDialog(QuizActivity.this);

                // 다이얼로그를 호출
                // 다이얼로그 내용을 결정할 정수도 같이 넘겨줌
                customDialog.callFunction(1);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CustomDialog customDialog = new CustomDialog(QuizActivity.this);
                customDialog.callFunction(2);
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CustomDialog2 customDialog2 = new CustomDialog2(QuizActivity.this);
                customDialog2.callFunction(3);
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CustomDialog customDialog = new CustomDialog(QuizActivity.this);
                customDialog.callFunction(4);
            }
        });
    }
}
